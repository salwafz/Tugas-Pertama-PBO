/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class aves extends hewan {
    private int jumlahCakar;
    private String bentukParuh;

    public int getJumlahCakar() {
        return jumlahCakar;
    }

    public void setJumlahCakar(int jumlahCakar) {
        this.jumlahCakar = jumlahCakar;
    }

    public String getBentukParuh() {
        return bentukParuh;
    }

    public void setBentukParuh(String bentukParuh) {
        this.bentukParuh = bentukParuh;
    }
}
