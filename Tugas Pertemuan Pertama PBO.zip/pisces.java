/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class pisces extends hewan {
    private int jumlahSirip;
    private String habitat;

    public int getJumlahSirip() {
        return jumlahSirip;
    }

    public void setJumlahSirip(int jumlahSirip) {
        this.jumlahSirip = jumlahSirip;
    }

    public String getHabitat() {
        return habitat;
    }

    public void setHabitat(String habitat) {
        this.habitat = habitat;
    }
}
