/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class hewan extends makhlukHidup {
    private int jumlahKaki;
    private String berjalan;
    private String reproduksi;

    /**
     * @return the jumlahKaki
     */
    public int getJumlahKaki() {
        return jumlahKaki;
    }

    /**
     * @param jumlahKaki the jumlahKaki to set
     */
    public void setJumlahKaki(int jumlahKaki) {
        this.jumlahKaki = jumlahKaki;
    }

    /**
     * @return the berjalan
     */
    public String getBerjalan() {
        return berjalan;
    }

    /**
     * @param berjalan the berjalan to set
     */
    public void setBerjalan(String berjalan) {
        this.berjalan = berjalan;
    }

    /**
     * @return the reproduksi
     */
    public String getReproduksi() {
        return reproduksi;
    }

    /**
     * @param reproduksi the reproduksi to set
     */
    public void setReproduksi(String reproduksi) {
        this.reproduksi = reproduksi;
    }
}
