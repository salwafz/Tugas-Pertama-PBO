/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

public class tumbuhan extends makhlukHidup {
    private String warnaDaun;
    private String arahDaun;
    private String reproduksi;

    public String getWarnaDaun() {
        return warnaDaun;
    }

    public void setWarnaDaun(String warnaDaun) {
        this.warnaDaun = warnaDaun;
    }

    public String getArahDaun() {
        return arahDaun;
    }

    public void setArahDaun(String arahDaun) {
        this.arahDaun = arahDaun;
    }

    public String getReproduksi() {
        return reproduksi;
    }

    public void setReproduksi(String reproduksi) {
        this.reproduksi = reproduksi;
    }
}
