/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class mamalia extends hewan {
    private String suhuTubuh;
    private String jenisMakanan;

    public String getSuhuTubuh() {
        return suhuTubuh;
    }

    public void setSuhuTubuh(String suhuTubuh) {
        this.suhuTubuh = suhuTubuh;
    }

    public String getJenisMakanan() {
        return jenisMakanan;
    }

    public void setJenisMakanan(String jenisMakanan) {
        this.jenisMakanan = jenisMakanan;
    }
}
