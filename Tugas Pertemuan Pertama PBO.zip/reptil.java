/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class reptil extends hewan {
    private String kemampuanRegenerasi;
    private String jenisKulit;


    public String getKemampuanRegenerasi() {
        return kemampuanRegenerasi;
    }

    public void setKemampuanRegenerasi(String kemampuanRegenerasi) {
        this.kemampuanRegenerasi = kemampuanRegenerasi;
    }

    public String getJenisKulit() {
        return jenisKulit;
    }

    public void setJenisKulit(String jenisKulit) {
        this.jenisKulit = jenisKulit;
    }
}
