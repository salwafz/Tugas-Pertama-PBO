/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class amfibi extends hewan {
    private String perilaku;
    private String bentukTubuh;

    public String getPerilaku() {
        return perilaku;
    }

    public void setPerilaku(String perilaku) {
        this.perilaku = perilaku;
    }

    public String getBentukTubuh() {
        return bentukTubuh;
    }

    public void setBentukTubuh(String bentukTubuh) {
        this.bentukTubuh = bentukTubuh;
    }
}
