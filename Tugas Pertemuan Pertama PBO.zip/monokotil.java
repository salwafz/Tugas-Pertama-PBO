/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class monokotil extends tumbuhan {
    private String bentukTulangDaun;
    private String bentukAkar;

    public String getBentukTulangDaun() {
        return bentukTulangDaun;
    }

    public void setBentukTulangDaun(String bentukTulangDaun) {
        this.bentukTulangDaun = bentukTulangDaun;
    }

    public String getBentukAkar() {
        return bentukAkar;
    }

    public void setBentukAkar(String bentukAkar) {
        this.bentukAkar = bentukAkar;
    }
}
