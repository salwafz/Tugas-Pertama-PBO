/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanPertama;

/**
 *
 * @author Salwa Faizah
 */
public class dikotil extends tumbuhan {
    private int jumlahKelopakBunga;
    private int jumlahBiji;

    public int getJumlahKelopakBunga() {
        return jumlahKelopakBunga;
    }

    public void setJumlahKelopakBunga(int jumlahKelopakBunga) {
        this.jumlahKelopakBunga = jumlahKelopakBunga;
    }

    public int getJumlahBiji() {
        return jumlahBiji;
    }

    public void setJumlahBiji(int jumlahBiji) {
        this.jumlahBiji = jumlahBiji;
    }
}
